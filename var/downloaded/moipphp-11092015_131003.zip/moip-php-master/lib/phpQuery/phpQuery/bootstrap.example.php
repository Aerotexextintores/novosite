<?php
/**
 * Example of phpQuery bootstrap file.
 *
 * This file is executed everytime phpQuery is included. Use it to set all
 * your personal needs in the library.
 *
 * To activate this file, delete '.example' from filename.
 */
// probably you want to use one of those functions here
//phpQuery::ajaxAllowHost();
//phpQuery::ajaxAllowURL();
//phpQuery::plugin();
?>